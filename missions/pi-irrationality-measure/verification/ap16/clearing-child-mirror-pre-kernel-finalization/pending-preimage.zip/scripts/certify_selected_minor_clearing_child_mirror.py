"""Pure pending/actual private clearing-mirror certification; never Lean/API.

Actual certification is unavailable until the parent actual certificate,
Accepted publication and final two bounded compiler contexts are pinned.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import stage_selected_minor_clearing_child_mirror as stage
import certify_selected_minor_clearing_bound_node as old
import certify_full_row_minor_node as kernel
import validate_namespace_context_providers as context
SELF=Path(__file__).resolve();STD3={'propext','Classical.choice','Quot.sound'}
read,sha,need,rel=stage.read,stage.sha,stage.need,stage.rel

def equation_pairs(records, source, generated, source_refs, generated_refs):
    pairs = []
    for index, name in enumerate(stage.parent.EQUATIONS, 1):
        docs = []
        for side, types, refs in [('source', source, source_refs),
                                  ('generated', generated, generated_refs)]:
            primary, module, filename = stage.parent.equation_specs(side)[index - 1]
            pf = records[stage.parent.SOURCE_SNAPSHOT if side == 'source' else stage.parent.GENERATED_SNAPSHOT]
            d = old.written((stage.parent.STAGE if side == 'source' else stage.STAGE) / filename, pf)
            need(set(d) == {'side', 'expectedModule', 'primaryBinding',
                 'getEqnsForReturnedSome', 'actualEquationNames', 'equations',
                 'unfolding', 'probeMainModule', 'theoremProofValuesExported'}
                 and d['side'] == side and d['expectedModule'] == module
                 and d['probeMainModule'] == ('SourceSnapshot' if side == 'source' else 'GeneratedSnapshot')
                 and d['getEqnsForReturnedSome'] is True
                 and d['actualEquationNames'] == [name]
                 and d['theoremProofValuesExported'] is False
                 and len(d['equations']) == 1,
                 'Official equation API result differs: ' + name)
            pr = d['primaryBinding']
            need(set(pr) == {'actualName', 'userName', 'levelParams', 'kind',
                 'type', 'value', 'owner', 'axioms'}
                 and pr['actualName'] == pr['userName'] == primary
                 and pr['kind'] == 'def' and pr['value'] is not None
                 and set(pr['owner']) == {'kind', 'index', 'module'}
                 and pr['owner']['kind'] == 'ImportedModule'
                 and pr['owner']['module'] == module
                 and type(pr['owner']['index']) is int and pr['owner']['index'] >= 0,
                 'Official equation primary full Def/owner differs')
            kernel.checked_expr(pr['type'], set(pr['levelParams']))
            kernel.checked_expr(pr['value'], set(pr['levelParams']))
            need(len(pr['axioms']) == len(set(pr['axioms']))
                 and set(pr['axioms']) <= STD3,
                 'Primary Def axioms exceed Std3')
            eq = d['equations'][0]
            need(set(eq) == {'getter', 'inversePrimary', 'CI'}
                 and eq['getter'] == 'Lean.Meta.getEqnsFor?'
                 and eq['inversePrimary'] == primary,
                 'Official equation inverse primary differs')
            ci = eq['CI']
            need(set(ci) == set(pr) and ci['actualName'] == ci['userName'] == name
                 and ci['kind'] == 'theorem' and ci['value'] is None
                 and sorted(ci['axioms']) == refs[name]['axioms']
                 and kernel.normalized_type(ci) == kernel.normalized_type(types[name]),
                 'Official equation CI type/Std3 differs')
            ro = refs[name]['owner']
            need(ci['owner']['kind'] == ro['kind']
                 and ci['owner']['module'] == ro['module'],
                 'Official equation CI actual owner differs')
            if d['unfolding'] is not None:
                u = d['unfolding']
                need(set(u) == {'getter', 'CI'}
                     and u['getter'] == 'Lean.Meta.getUnfoldEqnFor?',
                     'Unexpected unfolding equation getter')
                uc = u['CI']
                need(set(uc) == set(pr) and uc['kind'] == 'theorem'
                     and uc['actualName'] == uc['userName'] and uc['value'] is None
                     and set(uc['axioms']) <= STD3
                     and uc['owner']['module'] in [module, d['probeMainModule']],
                     'Actual unfolding equation CI differs')
                kernel.checked_expr(uc['type'], set(uc['levelParams']))
            docs.append(d)
        a, b = docs
        pa, pb = a['primaryBinding'], b['primaryBinding']
        need(pa['levelParams'] == pb['levelParams']
             and pa['type'] == pb['type'] and pa['value'] == pb['value']
             and sorted(pa['axioms']) == sorted(pb['axioms']),
             'Original/generated primary complete Def type/value/Std3 differs')
        need((a['unfolding'] is None) == (b['unfolding'] is None),
             'Official unfolding API result differs')
        if a['unfolding'] is not None:
            ua, ub = a['unfolding']['CI'], b['unfolding']['CI']
            need(ua['actualName'] == ub['actualName']
                 and kernel.normalized_type(ua) == kernel.normalized_type(ub)
                 and sorted(ua['axioms']) == sorted(ub['axioms']),
                 'Official unfolding CI type/Std3 differs')
        pairs.append({'primary': pa['actualName'], 'equation': name,
                      'getter': 'Lean.Meta.getEqnsFor?',
                      'inverse_getter': 'Lean.Meta.isEqnThm?',
                      'actual_primary_definition_values_equal': True,
                      'equation_types_and_Std3_equal': True,
                      'source_owner': source_refs[name]['owner'],
                      'generated_owner': generated_refs[name]['owner'],
                      'json_sha256': {side + '-equation-' + str(index) + '.json':
                                      sha((stage.parent.STAGE if side == 'source' else stage.STAGE) / (side + '-equation-' + str(index) + '.json'))
                                      for side in ['source', 'generated']}})
    return pairs

def validate():
    stage.check_only();parent=stage.parent
    previous=old.validate();need(parent.encode(previous)==(parent.STAGE/parent.CERTIFICATE).read_bytes(),'Historical clearing source certificate does not replay exactly')
    p=read(stage.STAGE/'preparation.json');records={}
    need(p['accepted_parent_Proved'] is True and p['private_helper_count']==18 and p['public_platform_boundary_names']==[parent.TARGET],'Final Accepted/private parent boundary differs')
    for i,(f,mode,module) in enumerate([(stage.OUTPUT,'emit-olean',stage.MODULE),(stage.SNAPSHOT,'modecheck','GeneratedSnapshot')],1):
        r=context.record(stage.STAGE/f,stage.STAGE/f'c{i}.json',mode,module,stage.STAGE);d=r['data']
        need(d['success'] is True and d['exit_code']==0 and d['timed_out'] is False and 0<d['seconds']<=300 and d['timeout_seconds']==300 and d['mode']==mode and 'emit_olean' not in d,'Actual bounded mirror compiler failed')
        if mode=='modecheck':need(d['output_olean'] is None and d['output_olean_sha256'] is None,'Snapshot emitted OLean')
        records[f]=r
    olean=parent.base.runner.STAGED_LIB/Path(stage.OUTPUT).with_suffix('.olean');e=records[stage.OUTPUT]['data'];need(e['output_olean']==rel(olean) and e['output_olean_sha256']==sha(olean),'Actual private mirror OLean differs')
    dep=kernel.imported_dep(records[stage.SNAPSHOT],stage.MODULE);need(Path(dep['path']).resolve()==olean.resolve() and dep['sha256_before']==sha(olean),'Snapshot imported a different mirror OLean')
    mapping_doc=old.written(stage.STAGE/stage.MAPPING_JSON,records[stage.SNAPSHOT])
    need(set(mapping_doc)=={'schemaVersion','probeMainModule','mirrorModule','mapping','publicTarget','actualOwnedPublicNames','officialDataEquationCandidates'} and mapping_doc['schemaVersion']==1 and mapping_doc['probeMainModule']=='GeneratedSnapshot' and mapping_doc['mirrorModule']==stage.MODULE and mapping_doc['publicTarget']==parent.TARGET and mapping_doc['officialDataEquationCandidates']==parent.EQUATIONS,'Actual exact private-name mapping envelope differs')
    helpers=read(parent.STAGE/'preparation.json')['inline_helper_names'];pairs=mapping_doc['mapping'];need(len(pairs)==18 and [r['sourceName'] for r in pairs]==helpers and len({r['actualName'] for r in pairs})==18,'Actual private-name finite domain differs')
    mapping={}
    for row in pairs:
        need(set(row)=={'sourceName','actualName','privateUserName','owner'} and row['privateUserName']==row['sourceName'] and row['actualName']!=row['sourceName'],'Actual private identity mapping differs')
        kernel.imported_owner(row,stage.MODULE);mapping[row['sourceName']]=row['actualName']
    public=mapping_doc['actualOwnedPublicNames'];need(public==sorted(set(public)) and parent.TARGET in public and set(public)<=set([parent.TARGET]+parent.EQUATIONS) and not set(helpers)&set(public),'Mirror exports an unintended public helper')
    source_names=helpers+[parent.TARGET]+parent.EQUATIONS;generated_names=[mapping[n] for n in helpers]+[parent.TARGET]+parent.EQUATIONS
    source_pf=previous['preflights'][parent.SOURCE_SNAPSHOT];source=old.type_rows(parent.SOURCE_TYPE_JSON,source_pf,source_names);boundary=set(p['provider_subtracted_names'])
    source_refs=old.proof_rows(parent.SOURCE_REFS_JSON,source_pf,'source',source_names,list(parent.HELPER_NAMES)+['SourceSnapshot'],boundary)
    saved=old.STAGE
    try:
        old.STAGE=stage.STAGE
        generated=old.type_rows(stage.TYPE_JSON,records[stage.SNAPSHOT],generated_names)
        modules=[stage.MODULE,parent.scales.PLATFORM_MODULE,parent.child.MODULE]+[parent.base.ap10.config(k)['platform_module'] for k in parent.base.ap10.CONFIGS]+['GeneratedSnapshot']
        generated_refs=old.proof_rows(stage.REFS_JSON,records[stage.SNAPSHOT],'generated',generated_names,modules,boundary)
    finally:old.STAGE=saved
    mapping.update({n:n for n in [parent.TARGET]+parent.EQUATIONS});roots_map=dict(mapping)
    extras=old.pair_extra({n:r for n,r in source_refs.items() if n not in roots_map},{n:r for n,r in generated_refs.items() if n not in roots_map.values()},roots_map);mapping=extras
    for n,m in roots_map.items():
        a,b=source[n],generated[m];need(kernel.normalized_type(a)[0]==kernel.normalized_type(b)[0] and kernel.rename_expr(kernel.normalized_type(a)[1],mapping)==kernel.normalized_type(b)[1],'Original/private helper full type differs')
    actual_external_deltas={}
    historical_deltas=previous['actual_external_instance_reference_differences']
    need(set(historical_deltas)==set(old.EXTERNAL_INSTANCE_DELTAS) and all(historical_deltas[n]==old.EXTERNAL_INSTANCE_DELTAS[n]|{'fields':['valueRefs','allUsedConstants']} for n in historical_deltas),'Exact historical external-instance difference contract does not replay')
    for n,m in mapping.items():
        a,b=source_refs[n],generated_refs[m];need(kernel.normalized_type(a)[0]==kernel.normalized_type(b)[0] and kernel.rename_expr(kernel.normalized_type(a)[1],mapping)==kernel.normalized_type(b)[1] and a['axioms']==b['axioms'],'Actual private CI type/Std3 differs')
        for f in ['typeRefs','valueRefs','allUsedConstants']:
            left={mapping.get(x,x) for x in a[f]};right=set(b[f]);source_only=sorted(left-right);generated_only=sorted(right-left)
            project=lambda x:x.startswith('OAI.') or x.startswith('_private.') and '.OAI.' in x or x in source_refs or x in generated_refs
            need({x for x in left if project(x)}=={x for x in right if project(x)},'Actual private project constants differ under exact kernel-name mapping: '+n+':'+f)
            if f=='typeRefs':need(not source_only and not generated_only,'Actual private complete type references differ: '+n)
            elif source_only or generated_only:
                expected=old.EXTERNAL_INSTANCE_DELTAS.get(n)
                need(expected is not None and source_only==expected['source_only'] and generated_only==expected['generated_only'] and all(not project(x) for x in source_only+generated_only),'Private mirror has an unrecorded external instance-reference difference: '+n+':'+f)
                actual_external_deltas.setdefault(n,{'source_only':source_only,'generated_only':generated_only,'fields':[]})['fields'].append(f)
        for x in b['allUsedConstants']:
            if x.startswith('OAI.') or x.startswith('_private.') and '.OAI.' in x:need(x in generated_refs or x in boundary,'Actual private mirror project dependency lacks closed provenance')
    need(set(actual_external_deltas)<=set(historical_deltas) and all(v['fields']==['valueRefs','allUsedConstants'] for v in actual_external_deltas.values()),'Actual finite mirror instance difference fields/domain differ')
    for row in pairs:need(generated_refs[row['actualName']]['owner']==row['owner'],'Actual private proof owner differs from exact resolver evidence')
    equations=equation_pairs({parent.SOURCE_SNAPSHOT:source_pf,parent.GENERATED_SNAPSHOT:records[stage.SNAPSHOT]},source,generated,source_refs,generated_refs)
    prior={}
    for key,w in previous['actual_provider_bindings'].items():
        module=w['module'];cached=stage.TASK/w['olean'];d=kernel.imported_dep(records[stage.OUTPUT],module);need(Path(d['path']).resolve()==cached.resolve() and d['sha256_before']==sha(cached)==w['olean_sha256'],'Private mirror prerequisite OLean differs');prior[key]=w
    return {'schema_version':1,'artifact_kind':'ap16-private-clearing-child-mirror-validation','source_commit':parent.COMMIT,'source_name':parent.TARGET,'platform_module':stage.MODULE,'public_platform_boundary_names':[parent.TARGET],'private_helper_count':18,'actual_private_helper_mappings':pairs,'actual_owned_public_names':public,'actual_automatic_CI_pairs':[[n,m] for n,m in mapping.items() if n not in roots_map],'provider_source_sha256':sha(stage.STAGE/stage.OUTPUT),'provider_olean':rel(olean),'provider_olean_sha256':sha(olean),'preparation_sha256':sha(stage.STAGE/'preparation.json'),'historical_source_certificate_sha256':sha(parent.STAGE/parent.CERTIFICATE),'preflights':records,'source_and_generated_types_equal':True,'source_and_generated_actual_proof_references_paired':True,'all_original_proof_suffixes_unchanged':True,'official_equation_pairs':equations,'actual_prior_provider_bindings':prior,'actual_external_instance_reference_differences':actual_external_deltas,'allowed_external_instance_difference_contract':old.EXTERNAL_INSTANCE_DELTAS,'historical_external_instance_difference_contract_sha256':stage.sha_bytes(stage.encode(historical_deltas)),'all_project_references_exact_under_actual_private_mapping':True,'Std3_only':True,'max_file_seconds':max(r['data']['seconds'] for r in records.values()),'implementation_hashes':{rel(f):sha(f) for f in [SELF,stage.SELF,Path(old.__file__),Path(kernel.__file__),Path(context.__file__)]},'generated_json_sha256':{f:sha(stage.STAGE/f) for f in [stage.TYPE_JSON,stage.REFS_JSON,stage.MAPPING_JSON]},'validated':True,'submission_ready':False,'proposal_status':'Draft','Lean_started_by_consumer':False,'API_used':False}

def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group(required=True);g.add_argument('--check-pending',action='store_true');g.add_argument('--certify-existing',action='store_true');g.add_argument('--check-only',action='store_true');a=p.parse_args()
    if a.check_pending:print(json.dumps(stage.pending_check(),ensure_ascii=False,indent=2));return
    r=validate();path=stage.STAGE/stage.CERTIFICATE;raw=stage.encode(r)
    if path.exists():need(path.read_bytes()==raw,'Existing private mirror certificate differs')
    elif a.certify_existing:path.write_bytes(raw)
    print(json.dumps({'certificate':rel(path),'certificate_sha256':sha(path) if path.exists() else None,'validated':True,'Std3_only':True,'max_file_seconds':r['max_file_seconds'],'Lean_started_by_consumer':False,'API_used':False},indent=2))
if __name__=='__main__':main()
